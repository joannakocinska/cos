package com.example.meow;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private final List<String> names = Arrays.asList("Anna", "Jan", "Katarzyna", "Piotr", "Maria", "Tomasz", "Agnieszka", "Krzysztof", "Barbara", "Andrzej");
    private final List<String> surnames = Arrays.asList("Kowalski", "Nowak", "Wiśniewski", "Dąbrowski", "Lewandowski", "Wójcik", "Kamiński", "Zieliński", "Szymański", "Woźniak");
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText inputNumber = findViewById(R.id.inputNumber);
        Button buttonGet = findViewById(R.id.buttonGet);

        buttonGet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = inputNumber.getText().toString();
                if (!input.isEmpty()) {
                    int count = Integer.parseInt(input);
                    List<Person> personList = new ArrayList<>();
                    for (int i = 0; i < count; i++) {
                        String randomName = names.get(random.nextInt(names.size()));
                        String randomSurname = surnames.get(random.nextInt(surnames.size()));
                        int randomNumber = random.nextInt(1_000_000) + 1;
                        personList.add(new Person(randomName, randomSurname, randomNumber));
                    }

                    Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                    intent.putExtra("personList", new ArrayList<>(personList));
                    startActivity(intent);
                }
            }
        });
    }
}
