package com.example.meow;
import java.io.Serializable;

public class Person implements Serializable {
    private String name;
    private String surname;
    private int randomNumber;



    public Person(String name, String surname, int randomNumber) {
        this.name = name;
        this.surname = surname;
        this.randomNumber = randomNumber;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public int getRandomNumber() {
        return randomNumber;
    }
}
