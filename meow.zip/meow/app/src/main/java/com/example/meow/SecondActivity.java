package com.example.meow;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class SecondActivity extends AppCompatActivity {

    private List<Person> personList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        personList = (ArrayList<Person>) getIntent().getSerializableExtra("personList");

        ListView listView = findViewById(R.id.listView);


        List<String> displayNames = new ArrayList<>();
        for (Person person : personList) {
            displayNames.add(person.getName() + " " + person.getSurname() + " - " + person.getRandomNumber());
        }


        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, displayNames);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Person clickedPerson = personList.get(position);
                showPersonDetailsDialog(clickedPerson);
            }
        });
    }

    private void showPersonDetailsDialog(Person person) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        String fullName = person.getName() + " " + person.getSurname();
        String number = String.valueOf(person.getRandomNumber());
        SpannableString spannableMessage = new SpannableString(number);
        spannableMessage.setSpan(new RelativeSizeSpan(1.5f), 0, spannableMessage.length(), 0);

        builder.setTitle(fullName);
        builder.setMessage(spannableMessage);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }


}
